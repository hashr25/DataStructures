#include "Sort.h"

Sort::Sort()
{
    ///Nothing to initialize
}
