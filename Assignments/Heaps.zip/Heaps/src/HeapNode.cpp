#include "HeapNode.h"

HeapNode::HeapNode(int value)
{
    this -> value = value;
    leftChild = NULL;
    rightChild = NULL;
}





