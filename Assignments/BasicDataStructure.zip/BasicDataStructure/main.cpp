#include <iostream>

#include "Queue.h"
#include "Stack.h"

using namespace std;

int main()
{
    cout << "Hello world!" << endl;
    return 0;
}
