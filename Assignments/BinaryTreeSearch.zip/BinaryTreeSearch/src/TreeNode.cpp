#include "TreeNode.h"

TreeNode::TreeNode(int value)
{
    this -> value = value;
    leftChild = NULL;
    rightChild = NULL;
}
